﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameFifteen
{
   public class TopScores
   {
       //this is the top score table
      public static int[] hodove = new int[5];
      public static string[] igrachi = new string[5];
      
      
   }
}
