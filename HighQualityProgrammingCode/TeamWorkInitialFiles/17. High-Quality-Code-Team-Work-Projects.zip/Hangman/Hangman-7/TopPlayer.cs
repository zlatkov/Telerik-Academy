﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hangman
{
    class TopPlayer
    {
        public string PlayerName { get; set; }
        public double PlayerScore { get; set; }
    }
}