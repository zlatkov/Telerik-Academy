namespace Labyrinth
{
    public class Table
    {
        public int moves;
        public string name;

        public Table(int moves, string name)
        {
            this.moves = moves;
            this.name = name;
        }
    }
}