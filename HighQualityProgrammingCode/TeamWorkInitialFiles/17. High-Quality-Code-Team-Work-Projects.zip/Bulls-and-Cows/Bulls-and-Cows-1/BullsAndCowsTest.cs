﻿
public class BullsAndCowsTest
{
    static void Main(string[] args)
    {
		cows_buls.Play();
    }
}

