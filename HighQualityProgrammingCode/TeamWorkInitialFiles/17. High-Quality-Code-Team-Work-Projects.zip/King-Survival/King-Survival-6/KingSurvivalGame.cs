﻿using System;

namespace KingSurvivalGame
{
    class KingSurvivalGame : KingPawsGame
    {
        static void Main()
        {
            InteractWithUser(counter);
            Console.WriteLine("\nThank you for using this game!\n\n");
        }             
    }
}